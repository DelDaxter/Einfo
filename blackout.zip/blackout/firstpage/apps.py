from django.apps import AppConfig


class FirstpageConfig(AppConfig):
    name = 'firstpage'
