from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User

class Profil(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)  # La liaison OneToOne vers le modèle User

    def __str__(self):
        return "Profil de {0}".format(self.user.username)

class Type(models.Model):
    nom = models.CharField(max_length=30)

    def __str__(self):
        return self.nom

class bar(models.Model):
    id = models.AutoField(primary_key=True)
    nom = models.CharField(max_length=100)
    adresse = models.CharField(max_length=100)
    slug = models.SlugField(max_length=100)
    contenu = models.TextField(null=True)
    photo = models.ImageField(upload_to="photos/")
    Hdebut=models.CharField(max_length=100)
    Hfin=models.CharField(max_length=100)
    P=models.CharField(max_length=100)
    type_de_bar = models.ForeignKey('Type',on_delete=models.CASCADE)


    class Meta:
        verbose_name = "Bar"


    def __str__(self):
        return self.nom
