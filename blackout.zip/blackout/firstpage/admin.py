from django.contrib import admin
from .models import Profil, bar, Type


admin.site.register(Profil)
admin.site.register(bar)
admin.site.register(Type)
