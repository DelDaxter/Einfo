from django import forms
from.models import Profil
from django.contrib.auth.forms import PasswordChangeForm, UserChangeForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class ConnexionForm(forms.Form):
    username = forms.CharField(label="Nom d'utilisateur",max_length=30,widget=forms.TextInput(attrs={'class' : 'input-field', 'placeholder' : 'Identifiant'}))
    password = forms.CharField(label="Mot de passe",widget=forms.PasswordInput(attrs={'class' : 'input-field', 'placeholder' : 'Mot de passe'}))

class InscriptionForm(forms.Form):
    first_name = forms.CharField(label="Prénom", max_length = 30,widget=forms.TextInput(attrs={'class' : 'form-control', 'id' : 'prn','placeholder' : 'Prénom'}))
    last_name = forms.CharField(label="Nom", max_length = 30,widget=forms.TextInput(attrs={'class' : 'form-control', 'id' : 'ndf','placeholder' : 'Nom'}))
    username = forms.CharField(label="Pseudo", max_length=30,widget=forms.TextInput(attrs={'class' : 'form-control','placeholder' : 'Pseudo', 'id' : 'username'}))
    email = forms.EmailField(label="Mail", widget=forms.EmailInput(attrs={'class' : 'form-control','placeholder' : 'Adresse mail', 'id' : 'mail'}))
    password = forms.CharField(label="Mot de passe", widget=forms.PasswordInput(attrs={'class' : 'form-control','placeholder' : 'Mot de passe', 'id' : 'pwd'}))

class FormChangePassword(PasswordChangeForm):
    def __init__(self, *args, **kwargs):
        super(FormChangePassword, self).__init__(*args, **kwargs)
        for field in ('old_password', 'new_password1', 'new_password2'):
            self.fields[field].widget.attrs = {'class': 'form-control', 'id' : 'pwd'}


class FormChangeUser(UserChangeForm):
    class Meta:
        model = User
        fields = ('email', 'first_name', 'last_name',)
    def clean_password(self):
        return ""
    def __init__(self, *args, **kwargs):
        super(FormChangeUser, self).__init__(*args, **kwargs)
        for field in ('email', 'first_name', 'last_name'):
            self.fields[field].widget.attrs = {'class': 'form-control', 'id' : 'pwd'}
