from django.contrib import admin
from django.urls import path, include
from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.home, name='accueil'),
    path('bar/<int:id>', views.infobar, name="infobar"),
    url('deconnexion', views.deconnexion, name='deconnexion'),
    url('connexion', views.connexion, name='connexion'),
    url('inscription', views.inscription, name='inscription'),
    url('profil', views.profil, name='profil'),
    url('password', views.change_password, name='change_password'),
    url('trouverbar', views.trouverbar, name='trouverbar'),

]
