var uluru = {lat: -25.363, lng: 131.044};
var paris = {lat: 48.852969,lng: 2.349873};
var map;


function initMap() {

  map = new google.maps.Map(document.getElementById('map'), {
      center: paris,
      zoom: 10,
      mapTypeId: 'roadmap'
    });

  recherche(map);

	var bar1 = new google.maps.Marker({
	    position: {lat: 48.827409, lng: 2.241672},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Brasserie Billancourt'
	  });

	  var content1 = '<p>Brasserie Billancourt,</p> <p> 4 Place Jules Guesde, 92100 Boulogne-Billancourt</p>'

	  var infowindow1 = new google.maps.InfoWindow({
	    content: content1
	  });


	 	google.maps.event.addListener(bar1, 'click', function() {
                if(!bar1.open){
                    infowindow1.open(map,bar1);
                    bar1.open = true;
                }
                else{
                    infowindow1.close();
                    bar1.open = false;
                }
        });



	var bar2 = new google.maps.Marker({
	    position: {lat: 48.84821779999999, lng: 2.26392809999993},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Le Village Auteuil'
	  });
	  var content2 = '<p>Le Village Auteuil,</p> <p> 48 Rue Auteuil, 75016 Paris</p>'

	  var infowindow2 = new google.maps.InfoWindow({
	    content: content2
	  });

	 	google.maps.event.addListener(bar2, 'click', function() {
                if(!bar2.open){
                    infowindow2.open(map,bar2);
                    bar2.open = true;
                }
                else{
                    infowindow2.close();
                    bar2.open = false;
                }
        });


	var bar3 = new google.maps.Marker({
	    position: {lat: 48.894043, lng: 2.276883},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Au Limousin'
	  });
	  var content3 = '<p>Au Limousin,</p> <p> 6 Rue Greffulhe, 92300 Levallois-Perret</p>'

	  var infowindow3 = new google.maps.InfoWindow({
	    content: content3
	  });

	 	google.maps.event.addListener(bar3, 'click', function() {
                if(!bar3.open){
                    infowindow3.open(map,bar3);
                    bar3.open = true;
                }
                else{
                    infowindow3.close();
                    bar3.open = false;
                }
        });



	var bar4 = new google.maps.Marker({
	    position: {lat: 48.859614, lng: 2.352061},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Paris Beaubourg'
	  });
	  var content4 = '<p>Paris Beaubourg,</p> <p> 23 Rue Saint-Merri, 75004 Paris</p>'

	  var infowindow4 = new google.maps.InfoWindow({
	    content: content4
	  });

	 	google.maps.event.addListener(bar4, 'click', function() {
                if(!bar4.open){
                    infowindow4.open(map,bar4);
                    bar4.open = true;
                }
                else{
                    infowindow4.close();
                    bar4.open = false;
                }
        });


var bar5 = new google.maps.Marker({
	    position: {lat: 48.86865, lng: 2.324894},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Relais Madeleine'
	  });
	  var content5 = '<p>Relais Madeleine,</p> <p> 9 Rue du Chevalier de Saint-George, 75008 Paris</p>'

	  var infowindow5 = new google.maps.InfoWindow({
	    content: content5
	  });

	 	google.maps.event.addListener(bar5, 'click', function() {
                if(!bar5.open){
                    infowindow5.open(map,bar5);
                    bar5.open = true;
                }
                else{
                    infowindow5.close();
                    bar5.open = false;
                }
        });

var bar6 = new google.maps.Marker({
	    position: {lat: 48.853617, lng: 2.368307},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Café des Phares'
	  });
	  var content6 = '<p>Café des Phares,</p> <p> 7 Place de la Bastille, 75004 Paris</p>'

	  var infowindow6 = new google.maps.InfoWindow({
	    content: content6
	  });

	 	google.maps.event.addListener(bar6, 'click', function() {
                if(!bar6.open){
                    infowindow6.open(map,bar6);
                    bar6.open = true;
                }
                else{
                    infowindow6.close();
                    bar6.open = false;
                }
        });

var bar7 = new google.maps.Marker({
	    position: {lat: 48.838025, lng: 2.278254},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Ahthentik'
	  });
	  var content7 = '<p>Authentik,</p> <p> 90 Rue Balard, 75015 Paris</p>'

	  var infowindow7 = new google.maps.InfoWindow({
	    content: content7
	  });

	 	google.maps.event.addListener(bar7, 'click', function() {
                if(!bar7.open){
                    infowindow7.open(map,bar7);
                    bar7.open = true;
                }
                else{
                    infowindow7.close();
                    bar7.open = false;
                }
        });


var bar8 = new google.maps.Marker({
	    position: {lat: 48.848091, lng: 2.37115},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'TarMac'
	  });
	  var content8 = '<p>TarMac,</p> <p> 33 Rue de Lyon, 75012 Paris</p>'

	  var infowindow8 = new google.maps.InfoWindow({
	    content: content8
	  });

	 	google.maps.event.addListener(bar8, 'click', function() {
                if(!bar8.open){
                    infowindow8.open(map,bar8);
                    bar8.open = true;
                }
                else{
                    infowindow8.close();
                    bar8.open = false;
                }
        });


var bar9 = new google.maps.Marker({
	    position: {lat: 48.882227, lng: 2.329122},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Chaizelle'
	  });
	  var content9 = '<p>Chaizelle,</p> <p> 34 Rue Ballu, 75009 Paris</p>'

	  var infowindow9 = new google.maps.InfoWindow({
	    content: content9
	  });

	 	google.maps.event.addListener(bar9, 'click', function() {
                if(!bar9.open){
                    infowindow9.open(map,bar9);
                    bar9.open = true;
                }
                else{
                    infowindow9.close();
                    bar9.open = false;
                }
        });

var bar10 = new google.maps.Marker({
	    position: {lat: 48.895553, lng: 2.22715},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Les Bambins'
	  });
	  var content10 = '<p>Les Bambins,</p> <p> 613 Terrasse de l`Arche, 92000 Nanterre</p>'

	  var infowindow10 = new google.maps.InfoWindow({
	    content: content10
	  });

	 	google.maps.event.addListener(bar10, 'click', function() {
                if(!bar10.open){
                    infowindow10.open(map,bar10);
                    bar10.open = true;
                }
                else{
                    infowindow10.close();
                    bar10.open = false;
                }
        });


var bar11 = new google.maps.Marker({
	    position: {lat: 48.840797, lng: 2.288871},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'L`Argument'
	  });
	  var content11 = '<p>L`Argument,</p> <p> 121 Rue de la Convention, 75015 Paris</p>'

	  var infowindow11 = new google.maps.InfoWindow({
	    content: content11
	  });

	 	google.maps.event.addListener(bar11, 'click', function() {
                if(!bar11.open){
                    infowindow11.open(map,bar11);
                    bar11.open = true;
                }
                else{
                    infowindow11.close();
                    bar11.open = false;
                }
        });


var bar12 = new google.maps.Marker({
	    position: {lat: 48.8897895, lng: 2.3387442000000647},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Chez Ginette'
	  });
	  var content12 = '<p>Chez Ginette,</p> <p> 101 Rue Caulaincourt, 75018 Paris</p>'

	  var infowindow12 = new google.maps.InfoWindow({
	    content: content12
	  });

	 	google.maps.event.addListener(bar12, 'click', function() {
                if(!bar12.open){
                    infowindow12.open(map,bar12);
                    bar12.open = true;
                }
                else{
                    infowindow12.close();
                    bar12.open = false;
                }
        });


var bar13 = new google.maps.Marker({
	    position: {lat: 48.81180588741942, lng: 2.4299633502960205},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Le Bar Belge'
	  });
	  var content13 = '<p>Le Bar Belge,</p> <p> 97 Avenue du Général Leclerc, 94700 Maisons-Alfort</p>'

	  var infowindow13 = new google.maps.InfoWindow({
	    content: content13
	  });

	 	google.maps.event.addListener(bar13, 'click', function() {
                if(!bar13.open){
                    infowindow13.open(map,bar13);
                    bar13.open = true;
                }
                else{
                    infowindow13.close();
                    bar13.open = false;
                }
        });


var bar14 = new google.maps.Marker({
	    position: {lat: 48.8395007, lng: 2.3362975999999662},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Le Bullier'
	  });
	  var content14 = '<p>Le Bullier,</p> <p> 22 Avenue de l`Observatoire, 75014 Paris</p>'

	  var infowindow14 = new google.maps.InfoWindow({
	    content: content14
	  });

	 	google.maps.event.addListener(bar14, 'click', function() {
                if(!bar14.open){
                    infowindow14.open(map,bar14);
                    bar14.open = true;
                }
                else{
                    infowindow14.close();
                    bar14.open = false;
                }
        });


var bar15 = new google.maps.Marker({
	    position: {lat: 48.87170683709267, lng: 2.339766025543213},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Le Cardinal'
	  });
	  var content15 = '<p>Le Cardinal,</p> <p> 1 Boulevard des Italiens, 75002 Paris</p>'

	  var infowindow15 = new google.maps.InfoWindow({
	    content: content15
	  });

	 	google.maps.event.addListener(bar15, 'click', function() {
                if(!bar15.open){
                    infowindow15.open(map,bar15);
                    bar15.open = true;
                }
                else{
                    infowindow15.close();
                    bar15.open = false;
                }
        });


var bar16 = new google.maps.Marker({
	    position: {lat: 48.7545000218094, lng: 2.301187813282013},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Le Café de la Gare'
	  });
	  var content16 = '<p>Le Café de la Gare,</p> <p> 6 Rue Velpeau, 92160 Antony</p>'

	  var infowindow16 = new google.maps.InfoWindow({
	    content: content16
	  });

	 	google.maps.event.addListener(bar16, 'click', function() {
                if(!bar16.open){
                    infowindow16.open(map,bar16);
                    bar16.open = true;
                }
                else{
                    infowindow16.close();
                    bar16.open = false;
                }
        });


var bar17 = new google.maps.Marker({
	    position: {lat: 48.86081691295477, lng: 2.3444759845733643},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Le Mimosa'
	  });
	  var content17 = '<p>Le Mimosa,</p> <p> 27 Rue du Pont Neuf, 75001 Paris</p>'

	  var infowindow17 = new google.maps.InfoWindow({
	    content: content17
	  });

	 	google.maps.event.addListener(bar17, 'click', function() {
                if(!bar17.open){
                    infowindow17.open(map,bar17);
                    bar17.open = true;
                }
                else{
                    infowindow17.close();
                    bar17.open = false;
                }
        });


var bar18 = new google.maps.Marker({
	    position: {lat: 48.85783199999999, lng: 2.370863999999983},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Le Verre à Ballon'
	  });
	  var content18 = '<p>Le Verre à Ballon,</p> <p> 33 Boulevard Richard Lenoir, 75011 Paris</p>'

	  var infowindow18 = new google.maps.InfoWindow({
	    content: content18
	  });

	 	google.maps.event.addListener(bar18, 'click', function() {
                if(!bar18.open){
                    infowindow18.open(map,bar18);
                    bar18.open = true;
                }
                else{
                    infowindow18.close();
                    bar18.open = false;
                }
        });


var bar19 = new google.maps.Marker({
	    position: {lat: 48.7934342, lng: 2.514213400000017},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'L`Etincelle'
	  });
	  var content19 = '<p>L`Etincelle,</p> <p> 86 Avenue du Bac, 94100 Saint-Maur-des-Fossés</p>'

	  var infowindow19 = new google.maps.InfoWindow({
	    content: content19
	  });

	 	google.maps.event.addListener(bar19, 'click', function() {
                if(!bar19.open){
                    infowindow19.open(map,bar19);
                    bar19.open = true;
                }
                else{
                    infowindow19.close();
                    bar19.open = false;
                }
        });


var bar20 = new google.maps.Marker({
	    position: {lat: 48.8492125, lng: 2.298455800000056},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Café Le Pierrot'
	  });
	  var content20 = '<p>Café Le Pierrot,</p> <p> 67 Avenue de la Motte-Picquet, 75015 Paris</p>'

	  var infowindow20 = new google.maps.InfoWindow({
	    content: content20
	  });

	 	google.maps.event.addListener(bar20, 'click', function() {
                if(!bar20.open){
                    infowindow20.open(map,bar20);
                    bar20.open = true;
                }
                else{
                    infowindow20.close();
                    bar20.open = false;
                }
        });


var bar21 = new google.maps.Marker({
	    position: {lat: 48.862727, lng: 2.339586000000054},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Café Blanc'
	  });
	  var content21 = '<p>Café Blanc,</p> <p> 10 Rue Croix des Petits Champs, 75001 Paris</p>'

	  var infowindow21 = new google.maps.InfoWindow({
	    content: content21
	  });

	 	google.maps.event.addListener(bar21, 'click', function() {
                if(!bar21.open){
                    infowindow21.open(map,bar21);
                    bar21.open = true;
                }
                else{
                    infowindow21.close();
                    bar21.open = false;
                }
        });


var bar22 = new google.maps.Marker({
	    position: {lat: 48.842707, lng: 2.3296530000000075},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Le Charivari'
	  });
	  var content22 = '<p>Le Charivari,</p> <p> 143 Boulevard Raspail, 75006 Paris</p>'

	  var infowindow22 = new google.maps.InfoWindow({
	    content: content22
	  });

	 	google.maps.event.addListener(bar22, 'click', function() {
                if(!bar22.open){
                    infowindow22.open(map,bar22);
                    bar22.open = true;
                }
                else{
                    infowindow22.close();
                    bar22.open = false;
                }
        });


var bar23 = new google.maps.Marker({
	    position: {lat: 48.8451701, lng: 2.2577804000000015},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Brasserie Moliteuil'
	  });
	  var content23 = '<p>Brasserie Moliteuil,</p> <p> 55 Rue Molitor, 75016 Paris</p>'

	  var infowindow23 = new google.maps.InfoWindow({
	    content: content23
	  });

	 	google.maps.event.addListener(bar23, 'click', function() {
                if(!bar23.open){
                    infowindow23.open(map,bar23);
                    bar23.open = true;
                }
                else{
                    infowindow23.close();
                    bar23.open = false;
                }
        });


var bar24 = new google.maps.Marker({
	    position: {lat: 48.857479943776774, lng: 2.346600294113159},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Bords de Seine'
	  });
	  var content24 = '<p>Bords de Seine,</p> <p> 2 Rue Edouard Colonne, 75001 Paris</p>'

	  var infowindow24 = new google.maps.InfoWindow({
	    content: content24
	  });

	 	google.maps.event.addListener(bar24, 'click', function() {
                if(!bar24.open){
                    infowindow24.open(map,bar24);
                    bar24.open = true;
                }
                else{
                    infowindow24.close();
                    bar24.open = false;
                }
        });


var bar25 = new google.maps.Marker({
	    position: {lat: 48.857479943776774, lng: 2.346600294113159},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Bistro Dupleix'
	  });
	  var content25 = '<p>Bistro Dupleix,</p> <p> 62 Boulevard de Grenelle, Paris</p>'

	  var infowindow25 = new google.maps.InfoWindow({
	    content: content25
	  });

	 	google.maps.event.addListener(bar25, 'click', function() {
                if(!bar25.open){
                    infowindow25.open(map,bar25);
                    bar25.open = true;
                }
                else{
                    infowindow25.close();
                    bar25.open = false;
                }
        });


var bar26 = new google.maps.Marker({
	    position: {lat: 48.8615721, lng: 2.351436700000022},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Le Cavalier Bleu'
	  });
	  var content26 = '<p>Le Cavalier Bleu,</p> <p> 143 Rue Saint-Martin, 75004 Paris</p>'

	  var infowindow26 = new google.maps.InfoWindow({
	    content: content26
	  });

	 	google.maps.event.addListener(bar26, 'click', function() {
                if(!bar26.open){
                    infowindow26.open(map,bar26);
                    bar26.open = true;
                }
                else{
                    infowindow26.close();
                    bar26.open = false;
                }
        });


var bar27 = new google.maps.Marker({
	    position: {lat: 48.87782299901039, lng: 2.3522624373435974},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Louis Caisse'
	  });
	  var content27 = '<p>Louis Caisse,</p> <p> 118 Rue la Fayette, 75010 Paris</p>'

	  var infowindow27 = new google.maps.InfoWindow({
	    content: content27
	  });

	 	google.maps.event.addListener(bar27, 'click', function() {
                if(!bar27.open){
                    infowindow27.open(map,bar27);
                    bar27.open = true;
                }
                else{
                    infowindow27.close();
                    bar27.open = false;
                }
        });


var bar28 = new google.maps.Marker({
	    position: {lat: 48.859937, lng: 2.309426},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Au Canon des Invalides'
	  });
	  var content28 = '<p>Au Canon des Invalides,</p> <p> 54 Rue Saint-Dominique, 75007 Paris</p>'

	  var infowindow28 = new google.maps.InfoWindow({
	    content: content28
	  });

	 	google.maps.event.addListener(bar28, 'click', function() {
                if(!bar28.open){
                    infowindow28.open(map,bar28);
                    bar28.open = true;
                }
                else{
                    infowindow28.close();
                    bar28.open = false;
                }
        });


var bar29 = new google.maps.Marker({
	    position: {lat: 48.8288172, lng: 2.2640407000000096},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Irish Café'
	  });
	  var content29 = '<p>Irish Café,</p> <p> 10 Rue Rouget de Lisle, 92130 Issy-les-Moulineaux</p>'

	  var infowindow29 = new google.maps.InfoWindow({
	    content: content29
	  });

	 	google.maps.event.addListener(bar29, 'click', function() {
                if(!bar29.open){
                    infowindow29.open(map,bar29);
                    bar29.open = true;
                }
                else{
                    infowindow29.close();
                    bar29.open = false;
                }
        });


var bar30 = new google.maps.Marker({
	    position: {lat: 48.8404731, lng: 2.324095599999964},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Café Gaité'
	  });
	  var content30 = '<p>Café Gaité,</p> <p> 10 Rue de la Gaité, 75014 Paris</p>'

	  var infowindow30 = new google.maps.InfoWindow({
	    content: content30
	  });

	 	google.maps.event.addListener(bar30, 'click', function() {
                if(!bar30.open){
                    infowindow30.open(map,bar30);
                    bar30.open = true;
                }
                else{
                    infowindow30.close();
                    bar30.open = false;
                }
        });


var bar31 = new google.maps.Marker({
	    position: {lat: 48.8585817, lng: 2.358337000000006},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Bar Du Marché Blancs Manteaux'
	  });
	  var content31 = '<p>31,</p> <p> 53 Rue Vieille du Temple, 75004 Paris</p>'

	  var infowindow31 = new google.maps.InfoWindow({
	    content: content31
	  });

	 	google.maps.event.addListener(bar31, 'click', function() {
                if(!bar31.open){
                    infowindow31.open(map,bar31);
                    bar31.open = true;
                }
                else{
                    infowindow31.close();
                    bar31.open = false;
                }
        });




var bar32 = new google.maps.Marker({
	    position: {lat: 48.8305559, lng: 2.3545195000000376},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Café O`Jules'
	  });
	  var content32 = '<p>Café O`Jules,</p> <p> 2 Rue Bobillot, 75013 Paris</p>'

	  var infowindow32 = new google.maps.InfoWindow({
	    content: content32
	  });

	 	google.maps.event.addListener(bar32, 'click', function() {
                if(!bar32.open){
                    infowindow32.open(map,bar32);
                    bar32.open = true;
                }
                else{
                    infowindow32.close();
                    bar32.open = false;
                }
        });


var bar33 = new google.maps.Marker({
	    position: {lat: 48.831485088108934, lng: 2.3409227281808853},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Au Réveil Samaritain'
	  });
	  var content33 = '<p>Au Réveil Samaritain,</p> <p> 3 Boulevard Saint-Jacques, 75014 Paris</p>'

	  var infowindow33 = new google.maps.InfoWindow({
	    content: content33
	  });

	 	google.maps.event.addListener(bar33, 'click', function() {
                if(!bar33.open){
                    infowindow33.open(map,bar33);
                    bar33.open = true;
                }
                else{
                    infowindow33.close();
                    bar33.open = false;
                }
        });



var bar34 = new google.maps.Marker({
	    position: {lat: 48.892553, lng: 2.3246544999999514},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Le Festiv`'
	  });
	  var content34 = '<p>Le Festiv`,</p> <p> 51 Rue Guy Môquet, 75017 Paris</p>'

	  var infowindow34 = new google.maps.InfoWindow({
	    content: content34
	  });

	 	google.maps.event.addListener(bar34, 'click', function() {
                if(!bar34.open){
                    infowindow34.open(map,bar34);
                    bar34.open = true;
                }
                else{
                    infowindow34.close();
                    bar34.open = false;
                }
        });



var bar35 = new google.maps.Marker({
	    position: {lat: 48.892553, lng: 2.3246544999999514},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Les Patios'
	  });
	  var content35 = '<p>Les Patios,</p> <p> 5 Place de la Sorbonne, Paris</p>'

	  var infowindow35 = new google.maps.InfoWindow({
	    content: content35
	  });

	 	google.maps.event.addListener(bar35, 'click', function() {
                if(!bar35.open){
                    infowindow35.open(map,bar35);
                    bar35.open = true;
                }
                else{
                    infowindow35.close();
                    bar35.open = false;
                }
        });


var bar36 = new google.maps.Marker({
	    position: {lat: 48.8962376, lng: 2.2251314000000093},
	    animation: google.maps.Animation.DROP,
	    map: map,
	    title: 'Le Sancerre'
	  });
	  var content36 = '<p>Le Sancerre,</p> <p> 449 Terrasse de l`Arche, 92000 Nanterre</p>'

	  var infowindow36 = new google.maps.InfoWindow({
	    content: content36
	  });

	 	google.maps.event.addListener(bar36, 'click', function() {
                if(!bar36.open){
                    infowindow36.open(map,bar36);
                    bar36.open = true;
                }
                else{
                    infowindow36.close();
                    bar36.open = false;
                }
        });

}
function geolocalisation(map){

  var infoWindow = new google.maps.InfoWindow({map: map});
  // Try HTML5 geolocation.
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var pos = {
        lat: position.coords.latitude,
        lng: position.coords.longitude
      };

      infoWindow.setPosition(pos);
      infoWindow.setContent('Vous êtes ici !');
      map.setCenter(pos);
      map.setZoom(16);

    }, function() {
      handleLocationError(true, infoWindow, map.getCenter());
    });
  } else {
    // Browser doesn't support Geolocation
    handleLocationError(false, infoWindow, map.getCenter());
  }
}

function recherche(map){
  // Create the search box and link it to the UI element.
  var input = document.getElementById('pac-input');
  var searchBox = new google.maps.places.SearchBox(input);
  map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

  // Bias the SearchBox results towards current map's viewport.
  map.addListener('bounds_changed', function() {
    searchBox.setBounds(map.getBounds());
  });

  var markers = [];
  // Listen for the event fired when the user selects a prediction and retrieve
  // more details for that place.
  searchBox.addListener('places_changed', function() {
    var places = searchBox.getPlaces();

    if (places.length == 0) {
      return;
    }

    // Clear out the old markers.
    markers.forEach(function(marker) {
      marker.setMap(null);
    });
    markers = [];

    // For each place, get the icon, name and location.
    var bounds = new google.maps.LatLngBounds();
    places.forEach(function(place) {
      if (!place.geometry) {
        console.log("Returned place contains no geometry");
        return;
      }
      var icon = {
        url: place.icon,
        size: new google.maps.Size(71, 71),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(17, 34),
        scaledSize: new google.maps.Size(25, 25)
      };

      // Create a marker for each place.
      markers.push(new google.maps.Marker({
        map: map,
        icon: icon,
        title: place.name,
        position: place.geometry.location
      }));

      if (place.geometry.viewport) {
        // Only geocodes have viewport.
        bounds.union(place.geometry.viewport);
      } else {
        bounds.extend(place.geometry.location);
      }
    });
    map.fitBounds(bounds);
  });
}



//			GEOLOCALISATON

// Note: This example requires that you consent to location sharing when
// prompted by your browser. If you see the error "The Geolocation service
// failed.", it means you probably did not give permission for the browser to
// locate you.

/*
function initMap() {
  var map = new google.maps.Map(document.getElementById('map'), {
    center: paris,
    zoom: 10
  });
  var infoWindow = new google.maps.InfoWindow({map: map});

  // Try HTML5 geolocation.
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var pos = {
        lat: position.coords.latitude,
        lng: position.coords.longitude
      };

      infoWindow.setPosition(pos);
      infoWindow.setContent('Vous êtes ici !');
      map.setCenter(pos);
      map.setZoom(16);

    }, function() {
      handleLocationError(true, infoWindow, map.getCenter());
    });
  } else {
    // Browser doesn't support Geolocation
    handleLocationError(false, infoWindow, map.getCenter());
  }
}

function handleLocationError(browserHasGeolocation, infoWindow, pos) {
  infoWindow.setPosition(pos);
  infoWindow.setContent(browserHasGeolocation ?
                        'Erreur, la Géolocalisation a échoué, actualiser la page.' :
                        'Erreur, votre navigateur ne supporte pas la Géolocalisation.');
}


//		SEARCH BOX

// This example adds a search box to a map, using the Google Place Autocomplete
// feature. People can enter geographical searches. The search box will return a
// pick list containing a mix of places and predicted search terms.


/*
function initAutocomplete() {
  var map = new google.maps.Map(document.getElementById('map'), {
    center: {lat: -33.8688, lng: 151.2195},
    zoom: 13,
    mapTypeId: 'roadmap'
  });

  // Create the search box and link it to the UI element.
  var input = document.getElementById('pac-input');
  var searchBox = new google.maps.places.SearchBox(input);
  map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

  // Bias the SearchBox results towards current map's viewport.
  map.addListener('bounds_changed', function() {
    searchBox.setBounds(map.getBounds());
  });

  var markers = [];
  // Listen for the event fired when the user selects a prediction and retrieve
  // more details for that place.
  searchBox.addListener('places_changed', function() {
    var places = searchBox.getPlaces();

    if (places.length == 0) {
      return;
    }

    // Clear out the old markers.
    markers.forEach(function(marker) {
      marker.setMap(null);
    });
    markers = [];

    // For each place, get the icon, name and location.
    var bounds = new google.maps.LatLngBounds();
    places.forEach(function(place) {
      if (!place.geometry) {
        console.log("Returned place contains no geometry");
        return;
      }
      var icon = {
        url: place.icon,
        size: new google.maps.Size(71, 71),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(17, 34),
        scaledSize: new google.maps.Size(25, 25)
      };

      // Create a marker for each place.
      markers.push(new google.maps.Marker({
        map: map,
        icon: icon,
        title: place.name,
        position: place.geometry.location
      }));

      if (place.geometry.viewport) {
        // Only geocodes have viewport.
        bounds.union(place.geometry.viewport);
      } else {
        bounds.extend(place.geometry.location);
      }
    });
    map.fitBounds(bounds);
  });
}

*/
