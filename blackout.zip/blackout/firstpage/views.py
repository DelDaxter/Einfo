from django.shortcuts import render, redirect
from django.http import HttpResponse, Http404
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.urls import reverse
from django.contrib.auth.forms import UserChangeForm
from .forms import ConnexionForm, InscriptionForm, FormChangePassword, FormChangeUser
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from firstpage.models import bar
from datetime import datetime



def home(request):
    return render(request, 'firstpage/accueil.html')

def inscription(request):
    if request.method == "POST":
        form = InscriptionForm(request.POST)
        if form.is_valid():
            first_name = form.cleaned_data["first_name"]
            last_name = form.cleaned_data["last_name"]
            username = form.cleaned_data["username"]
            email = form.cleaned_data["email"]
            password = form.cleaned_data["password"]
            user = User.objects.create_user(username=username, password=password, first_name = first_name, last_name = last_name, email = email)
            user.save()
            return redirect(home)
        else:
            print("form is not valid")
    else:
        form = InscriptionForm()
    return render(request, 'firstpage/inscription.html', locals())

def connexion(request):
    error = False
    if request.method == "POST":
        form = ConnexionForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            password = form.cleaned_data["password"]
            user = authenticate(username=username, password=password)  # Nous vérifions si les données sont correctes
            if user:  # Si l'objet renvoyé n'est pas None
                login(request, user)  # nous connectons l'utilisateur
                return redirect(home)
            else: # sinon une erreur sera affichée
                error = True
    else:
        form = ConnexionForm()
    return render(request, 'firstpage/connexion.html', locals())

def deconnexion(request):
    logout(request)
    return redirect(reverse(home))

def profil(request):
    error = False
    if request.method == "POST":
        form = FormChangeUser(request.POST, instance = request.user)
        if form.is_valid():
            user = form.save()
            messages.success(request,'Your password was successfully updated!')
            return redirect('accueil')
        else:
            error = True
    else:
        form = FormChangeUser(instance = request.user)
    return render(request, 'firstpage/profil.html', locals())

def change_password(request):
    error = False
    if request.method == "POST":
        form = FormChangePassword(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request,'Your password was successfully updated!')
            return redirect('accueil')
        else:
            error = True
    else:
        form = FormChangePassword(request.user)
    return render (request, 'firstpage/change_password.html', locals())

@login_required
def trouverbar(request):
    bars = bar.objects.all().order_by('nom')
    value = datetime.now()
    return render(request, 'firstpage/trouverbar.html', {'lesbar' : bars, 'value': value})

@login_required
def infobar(request, id):
    try:
        bars = bar.objects.get(id=id)
    except bars.DoesNotExist:
        raise Http404
    return render(request, 'firstpage/infobar.html', {'bar': bars})
# Create your views here.
